export const environment = {
  production: false,
  adminCode: 'gratitud2025',
  useFirebaseStorage: false,
  firebase: {
    apiKey: "AIzaSyBSA2-EFTx5Jis4oxgYUIn0MpItTPnQYm4",
    authDomain: "jolgorios-f5048.firebaseapp.com",
    projectId: "jolgorios-f5048",
    storageBucket: 'jolgorios-f5048.appspot.com',

//    storageBucket: 'jolgorios-f5048.firebasestorage.app', // <-- pon AQUÍ tu bucket real
    messagingSenderId: "692933170953",
    appId: "1:692933170953:web:0bf671888705de93dba5d8"
  }
};